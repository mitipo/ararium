# 프로젝트01(아라리움)

## 프로젝트 개요
- 프로젝트 기간 : 2023.08.11 ~ 2023.09.13

## 프로젝트 관련 자료
- Notion : [노션](https://www.notion.so/invite/dc4fed49f360a2bd5597e141f5f40ed0c8c0b3bd)
- 배포 URL : [배포](http://)